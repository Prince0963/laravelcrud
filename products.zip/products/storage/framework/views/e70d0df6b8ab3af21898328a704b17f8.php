<!DOCTYPE html>
<html>
<body>

<h2>products Detail</h2>


<h4>ID: <?php echo e($product->id); ?></h4>
<h4>Product Name: <?php echo e($product->name); ?></h4>
<h4>product Image: <img src="<?php echo e(Storage::url($product->image)); ?>" style="width: 100px; height: auto;"></h4>


<a href="<?php echo e(route('products.index')); ?>">Back</a>


</body>
</html>

<?php /**PATH C:\xampp\htdocs\laravelcrud\products\resources\views/product/show/show.blade.php ENDPATH**/ ?>