<!DOCTYPE html>
<html>

<head>
    <style>
        table {
            font-family: arial, sans-serif;
            border-collapse: collapse;
            width: 100%;
        }

        td,
        th {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }

        tr:nth-child(even) {
            background-color: #dddddd;
        }
    </style>
</head>

<body>

    <h2>Product Details</h2>

    <a href="<?php echo e(route('products.create')); ?>">Create</a>


    <table>
        <tr>
            <th>ID</th>
            <th>Product Name</th>
            <th>Product Description</th>
            <th>Product Image</th>
            <th>Action</th>
        </tr>
        <?php $__currentLoopData = $datalist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($data->id); ?></td>
            <td><?php echo e($data->name); ?></td>
            <td><?php echo e($data->description); ?></td>
            <td><img src="<?php echo e(Storage::url($data->image)); ?>" style="width: 100px; height: auto;" alt=""></td>
            <td>
                <a href="<?php echo e(route('products.show', $data->id)); ?>">Show</a>
                <a href="<?php echo e(route('products.edit', $data->id)); ?>">Edit</a>
                <form action="<?php echo e(route('products.destroy', $data->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>

                    <button type="submit">Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

</body>

</html><?php /**PATH C:\xampp\htdocs\laravelcrud\products\resources\views/product/index/index.blade.php ENDPATH**/ ?>